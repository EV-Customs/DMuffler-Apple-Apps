import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import * as WebBrowser from "expo-web-browser";
import React, { useState } from "react";
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BOOMBOX_CARS, BOOMBOX_PROFILES, BoomboxProfile, CARS, Car } from "@/constants/cars";
import { useDeviceConnection } from "@/context/DeviceConnectionContext";
import { useSoundSettings } from "@/context/SoundSettingsContext";
import { useColors } from "@/hooks/useColors";

const ORDER_URL = "https://tesmuffler.replit.app/#store";
type Tab = "car" | "boombox";

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { selectedCarId, setSelectedCarId } = useSoundSettings();
  const { status, connectedDevice } = useDeviceConnection();
  const [tab, setTab] = useState<Tab>("car");

  const statusLabel =
    status === "connected"
      ? `Connected to ${connectedDevice?.name ?? "DMuffler"}`
      : status === "connecting"
        ? "Connecting…"
        : status === "scanning"
          ? "Scanning…"
          : "No DMuffler device connected";

  const isWeb = Platform.OS === "web";
  const topInset = isWeb ? 67 : insets.top;
  const bottomInset = isWeb ? 34 : insets.bottom;

  const openOrder = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    WebBrowser.openBrowserAsync(ORDER_URL).catch(() => {});
  };

  const onSelectCar = (car: Car) => {
    if (Platform.OS !== "web") Haptics.selectionAsync();
    setSelectedCarId(car.id);
  };

  const openSettings = (car: Car) => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push(`/settings/${car.id}`);
  };

  const renderCar = ({ item }: { item: Car }) => {
    const selected = item.id === selectedCarId;
    return (
      <Pressable
        testID={`car-card-${item.id}`}
        onPress={() => onSelectCar(item)}
        style={[
          styles.card,
          {
            backgroundColor: colors.card,
            borderColor: selected ? colors.primary : "transparent",
          },
        ]}
      >
        <Image source={item.image} style={styles.cardImage} resizeMode="cover" />
        <LinearGradient
          colors={["rgba(10,10,10,0.1)", "rgba(10,10,10,0.85)"]}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.cardContent}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.carName, { color: colors.foreground }]}>
              {item.name.toUpperCase()}
            </Text>
            {item.subtitle ? (
              <Text style={[styles.boomboxDesc, { color: "rgba(255,255,255,0.65)", marginTop: 3 }]}>
                {item.subtitle}
              </Text>
            ) : null}
          </View>
          {item.subtitle ? (
            <View style={[styles.playBtn, { backgroundColor: colors.primary }]}>
              <Ionicons name="musical-notes" size={18} color={colors.primaryForeground} />
            </View>
          ) : (
            <Pressable
              testID={`car-settings-${item.id}`}
              hitSlop={12}
              onPress={() => openSettings(item)}
            >
              <Feather name="sliders" size={22} color={colors.foreground} />
            </Pressable>
          )}
        </View>
      </Pressable>
    );
  };

  const renderBoombox = ({
    item,
  }: {
    item: BoomboxProfile;
  }) => {
    const selected = item.id === selectedCarId;
    return (
    <Pressable
      testID={`boombox-card-${item.id}`}
      style={[styles.card, { backgroundColor: colors.card, borderColor: selected ? colors.primary : "transparent" }]}
      onPress={() => {
        if (Platform.OS !== "web") Haptics.selectionAsync();
        setSelectedCarId(item.id);
      }}
    >
      <Image source={item.image} style={styles.cardImage} resizeMode="cover" />
      <LinearGradient
        colors={["rgba(10,10,10,0.05)", "rgba(10,10,10,0.88)"]}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.cardContent}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.carName, { color: colors.foreground }]}>
            {item.name.toUpperCase()}
          </Text>
          <Text style={[styles.boomboxDesc, { color: "rgba(255,255,255,0.65)", marginTop: 3 }]}>
            {item.desc}
          </Text>
        </View>
        <View style={[styles.playBtn, { backgroundColor: colors.primary }]}>
          <Ionicons name="musical-notes" size={18} color={colors.primaryForeground} />
        </View>
      </View>
    </Pressable>
  );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar style="light" />

      {/* Header */}
      <View style={[styles.header, { paddingTop: topInset + 8 }]}>
        <Pressable
          testID="device-status"
          style={styles.statusRow}
          hitSlop={8}
          onPress={() => {
            if (Platform.OS !== "web") Haptics.selectionAsync();
            router.push("/pair");
          }}
        >
          <Ionicons
            name="bluetooth"
            size={13}
            color={status === "connected" ? colors.primary : colors.mutedForeground}
          />
          <Text
            style={[
              styles.statusText,
              {
                color:
                  status === "connected" ? colors.primary : colors.mutedForeground,
              },
            ]}
          >
            {statusLabel}
          </Text>
          <Feather
            name="chevron-right"
            size={13}
            color={status === "connected" ? colors.primary : colors.mutedForeground}
          />
        </Pressable>
      </View>

      {/* Segmented control */}
      <View style={styles.segmentWrap}>
        <View style={[styles.segment, { backgroundColor: colors.card }]}>
          <Pressable
            testID="tab-car"
            style={[
              styles.segmentBtn,
              tab === "car" && { backgroundColor: colors.primary },
            ]}
            onPress={() => setTab("car")}
          >
            <Text
              style={[
                styles.segmentText,
                {
                  color:
                    tab === "car" ? colors.primaryForeground : colors.mutedForeground,
                },
              ]}
            >
              CAR SOUNDS
            </Text>
          </Pressable>
          <Pressable
            testID="tab-boombox"
            style={[
              styles.segmentBtn,
              tab === "boombox" && { backgroundColor: colors.primary },
            ]}
            onPress={() => setTab("boombox")}
          >
            <Text
              style={[
                styles.segmentText,
                {
                  color:
                    tab === "boombox"
                      ? colors.primaryForeground
                      : colors.mutedForeground,
                },
              ]}
            >
              DIGITAL JAZZ
            </Text>
          </Pressable>
        </View>
      </View>

      {tab === "car" ? (
        <FlatList
          data={CARS}
          keyExtractor={(c) => c.id}
          renderItem={renderCar}
          contentContainerStyle={{
            paddingHorizontal: 16,
            paddingBottom: bottomInset + 90,
          }}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <FlatList
          data={BOOMBOX_CARS}
          keyExtractor={(c) => c.id}
          renderItem={renderCar}
          ListFooterComponent={
            <>
              {BOOMBOX_PROFILES.map((item) => (
                <React.Fragment key={item.id}>
                  {renderBoombox({ item })}
                </React.Fragment>
              ))}
            </>
          }
          contentContainerStyle={{
            paddingHorizontal: 16,
            paddingBottom: bottomInset + 90,
          }}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Sticky order button */}
      <View
        style={[
          styles.orderWrap,
          { paddingBottom: bottomInset + 12, backgroundColor: colors.background },
        ]}
      >
        <Pressable
          testID="order-device"
          onPress={openOrder}
          style={[styles.orderBtn, { backgroundColor: colors.primary }]}
        >
          <Text style={[styles.orderText, { color: colors.primaryForeground }]}>
            ORDER A DEVICE
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 16,
    paddingBottom: 8,
    alignItems: "center",
  },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
  statusText: { fontFamily: "Inter_500Medium", fontSize: 12 },
  segmentWrap: { paddingHorizontal: 16, paddingVertical: 12 },
  segment: {
    flexDirection: "row",
    borderRadius: 8,
    padding: 4,
  },
  segmentBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: "center",
    borderRadius: 6,
  },
  segmentText: { fontFamily: "Inter_700Bold", fontSize: 13, letterSpacing: 1 },
  card: {
    height: 130,
    borderRadius: 8,
    marginBottom: 12,
    overflow: "hidden",
    borderWidth: 2,
  },
  cardImage: { ...StyleSheet.absoluteFillObject, width: "100%", height: "100%" },
  cardContent: {
    ...StyleSheet.absoluteFillObject,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    padding: 16,
  },
  carName: { fontFamily: "Inter_700Bold", fontSize: 20, letterSpacing: 1 },
  boomboxDesc: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  playBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  orderWrap: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  orderBtn: {
    borderRadius: 28,
    paddingVertical: 16,
    alignItems: "center",
  },
  orderText: { fontFamily: "Inter_700Bold", fontSize: 15, letterSpacing: 1.5 },
});
