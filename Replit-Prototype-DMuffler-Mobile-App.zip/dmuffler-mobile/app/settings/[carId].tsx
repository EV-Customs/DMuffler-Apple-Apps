import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Slider } from "@/components/Slider";
import { getCar } from "@/constants/cars";
import { useDeviceConnection } from "@/context/DeviceConnectionContext";
import { SoundMode, useSoundSettings } from "@/context/SoundSettingsContext";
import { useColors } from "@/hooks/useColors";

const MODES: { key: SoundMode; label: string }[] = [
  { key: "city", label: "CITY" },
  { key: "sport", label: "SPORT" },
  { key: "own", label: "CUSTOM" },
];

export default function SoundSettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { carId } = useLocalSearchParams<{ carId: string }>();
  const car = getCar(carId);
  const { getModeSettings, updateModeSettings } = useSoundSettings();
  const { status, syncStatus, syncModeSettings } = useDeviceConnection();

  const [mode, setMode] = useState<SoundMode>("city");

  React.useEffect(() => {
    if (!carId || !car) {
      router.replace("/");
    }
  }, [carId, car, router]);

  const settings = getModeSettings(carId ?? "", mode);

  if (!carId || !car) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]} />
    );
  }

  const isWeb = Platform.OS === "web";
  const bottomInset = isWeb ? 34 : insets.bottom;

  const haptic = () => {
    if (Platform.OS !== "web") Haptics.selectionAsync();
  };

  const update = (patch: Parameters<typeof updateModeSettings>[2]) => {
    updateModeSettings(carId ?? "", mode, patch);
    // Push the updated mode settings to a connected DMuffler device.
    syncModeSettings(carId ?? "", mode, { ...settings, ...patch });
  };

  const changeBackfires = (delta: number) => {
    const next = Math.min(5, Math.max(0, settings.backfires + delta));
    if (next !== settings.backfires) {
      haptic();
      update({ backfires: next });
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar style="light" />
      <Stack.Screen
        options={{
          title: "SOUND SETTINGS",
          headerStyle: { backgroundColor: colors.background },
          headerTintColor: colors.foreground,
          headerTitleStyle: {
            fontFamily: "Inter_700Bold",
            fontSize: 16,
          },
          headerShadowVisible: false,
          headerLeft: () => (
            <Pressable
              testID="back-button"
              hitSlop={12}
              onPress={() => router.back()}
            >
              <Ionicons name="chevron-back" size={26} color={colors.foreground} />
            </Pressable>
          ),
        }}
      />

      <ScrollView
        contentContainerStyle={{
          padding: 16,
          paddingBottom: bottomInset + 24,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Car name chip */}
        <View style={[styles.chip, { backgroundColor: colors.card }]}>
          <Text style={[styles.chipText, { color: colors.foreground }]}>
            {(car?.name ?? "UNKNOWN").toUpperCase()}
          </Text>
        </View>

        {/* Device sync status */}
        {status === "connected" && (
          <View testID="sync-status" style={styles.syncRow}>
            <Ionicons
              name={
                syncStatus === "error"
                  ? "cloud-offline-outline"
                  : syncStatus === "syncing"
                    ? "sync-outline"
                    : "checkmark-circle-outline"
              }
              size={14}
              color={syncStatus === "error" ? "#E5484D" : colors.primary}
            />
            <Text
              style={[
                styles.syncText,
                {
                  color: syncStatus === "error" ? "#E5484D" : colors.primary,
                },
              ]}
            >
              {syncStatus === "syncing"
                ? "Syncing to device…"
                : syncStatus === "error"
                  ? "Sync failed — check device"
                  : syncStatus === "synced"
                    ? "Synced to device"
                    : "Device connected"}
            </Text>
          </View>
        )}

        {/* Mode segmented tabs */}
        <View style={[styles.modeRow, { borderColor: colors.primary }]}>
          {MODES.map((m, i) => {
            const active = m.key === mode;
            return (
              <Pressable
                key={m.key}
                testID={`mode-${m.key}`}
                onPress={() => {
                  haptic();
                  setMode(m.key);
                }}
                style={[
                  styles.modeBtn,
                  active && { backgroundColor: colors.primary },
                  i > 0 && { borderLeftWidth: 1, borderLeftColor: colors.primary },
                ]}
              >
                <Text
                  style={[
                    styles.modeText,
                    { color: active ? colors.primaryForeground : colors.primary },
                  ]}
                >
                  {m.label}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {/* Main volume */}
        <Text style={[styles.sectionLabel, { color: colors.foreground }]}>
          Main volume
        </Text>
        <View style={styles.sliderRow}>
          <Ionicons name="volume-low" size={22} color={colors.mutedForeground} />
          <Slider
            testID="volume-slider"
            value={settings.volume}
            onChange={(v) => update({ volume: v })}
          />
          <Ionicons name="volume-high" size={22} color={colors.mutedForeground} />
        </View>

        {/* Start mode */}
        <Text style={[styles.sectionLabel, { color: colors.foreground }]}>
          Start
        </Text>
        <View style={styles.startRow}>
          <Text
            style={[
              styles.startText,
              {
                color:
                  settings.startMode !== "off"
                    ? colors.foreground
                    : colors.mutedForeground,
                fontFamily:
                  settings.startMode !== "off"
                    ? "Inter_700Bold"
                    : "Inter_400Regular",
              },
            ]}
          >
            {settings.startMode !== "off" ? "On" : "Off"}
          </Text>
          <Switch
            testID="start-toggle"
            value={settings.startMode !== "off"}
            onValueChange={(on) => {
              haptic();
              update({ startMode: on ? "dynamic" : "off" });
            }}
            trackColor={{ false: colors.card, true: colors.primary }}
            thumbColor="#FFFFFF"
            ios_backgroundColor={colors.card}
          />
        </View>

        {/* Idle speed sound */}
        <Text style={[styles.sectionLabel, { color: colors.foreground }]}>
          Idle speed sound
        </Text>
        <View style={styles.sliderRow}>
          <Feather name="chevron-down" size={22} color={colors.mutedForeground} />
          <Slider
            testID="idle-slider"
            value={settings.idleSpeed}
            onChange={(v) => update({ idleSpeed: v })}
          />
          <Feather name="chevron-up" size={22} color={colors.mutedForeground} />
        </View>

        {/* Backfires stepper */}
        <Text style={[styles.sectionLabel, { color: colors.foreground }]}>
          Sound
        </Text>
        <View style={[styles.backfireRow, { borderTopColor: colors.border }]}>
          <Text style={[styles.backfireLabel, { color: colors.foreground }]}>
            Amount of backfires
          </Text>
          <View style={styles.stepper}>
            <Pressable
              testID="backfire-minus"
              hitSlop={10}
              onPress={() => changeBackfires(-1)}
            >
              <Feather name="minus" size={20} color={colors.primary} />
            </Pressable>
            <Text style={[styles.backfireValue, { color: colors.foreground }]}>
              {settings.backfires}
            </Text>
            <Pressable
              testID="backfire-plus"
              hitSlop={10}
              onPress={() => changeBackfires(1)}
            >
              <Feather name="plus" size={20} color={colors.primary} />
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  chip: {
    alignSelf: "center",
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 8,
    marginBottom: 20,
  },
  chipText: { fontFamily: "Inter_700Bold", fontSize: 16, letterSpacing: 2 },
  syncRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    marginTop: -8,
    marginBottom: 16,
  },
  syncText: { fontFamily: "Inter_500Medium", fontSize: 12 },
  modeRow: {
    flexDirection: "row",
    borderWidth: 1,
    borderRadius: 8,
    overflow: "hidden",
    marginBottom: 24,
  },
  modeBtn: { flex: 1, paddingVertical: 14, alignItems: "center" },
  modeText: { fontFamily: "Inter_700Bold", fontSize: 13, letterSpacing: 1 },
  sectionLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 15,
    marginBottom: 14,
    marginTop: 8,
  },
  sliderRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 24,
  },
  startRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  startText: { fontSize: 14 },
  backfireRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderTopWidth: 1,
    paddingTop: 16,
  },
  backfireLabel: { fontFamily: "Inter_400Regular", fontSize: 15 },
  stepper: { flexDirection: "row", alignItems: "center", gap: 18 },
  backfireValue: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    minWidth: 20,
    textAlign: "center",
  },
});
