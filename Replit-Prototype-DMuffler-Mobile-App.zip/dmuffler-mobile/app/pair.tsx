import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { Stack, useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useDeviceConnection } from "@/context/DeviceConnectionContext";
import { useColors } from "@/hooks/useColors";
import type { DiscoveredDevice } from "@/lib/device/transport";

export default function PairScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const {
    status,
    connectedDevice,
    discoveredDevices,
    scanError,
    connectError,
    startScan,
    connectToDevice,
    disconnect,
  } = useDeviceConnection();

  const [connectingId, setConnectingId] = useState<string | null>(null);
  const scanning = status === "scanning";

  useEffect(() => {
    startScan();
  }, [startScan]);

  const isWeb = Platform.OS === "web";
  const bottomInset = isWeb ? 34 : insets.bottom;

  const onConnect = async (device: DiscoveredDevice) => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setConnectingId(device.id);
    try {
      await connectToDevice(device);
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      router.back();
    } catch {
      // connectError is surfaced below
    } finally {
      setConnectingId(null);
    }
  };

  const onDisconnect = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    disconnect();
  };

  const renderDevice = ({ item }: { item: DiscoveredDevice }) => {
    const isConnected = connectedDevice?.id === item.id;
    const isConnecting = connectingId === item.id;
    return (
      <Pressable
        testID={`device-${item.id}`}
        onPress={() => (isConnected ? undefined : onConnect(item))}
        disabled={isConnecting || isConnected}
        style={[
          styles.deviceRow,
          {
            backgroundColor: colors.card,
            borderColor: isConnected ? colors.primary : "transparent",
          },
        ]}
      >
        <View style={[styles.deviceIcon, { backgroundColor: colors.background }]}>
          <Ionicons
            name={item.kind === "demo" ? "hardware-chip-outline" : "wifi"}
            size={20}
            color={isConnected ? colors.primary : colors.mutedForeground}
          />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.deviceName, { color: colors.foreground }]}>
            {item.name}
          </Text>
          <Text style={[styles.deviceMeta, { color: colors.mutedForeground }]}>
            {item.kind === "demo"
              ? "Simulated device — no hardware needed"
              : item.address}
          </Text>
        </View>
        {isConnecting ? (
          <ActivityIndicator size="small" color={colors.primary} />
        ) : isConnected ? (
          <View style={styles.connectedWrap}>
            <Text style={[styles.connectedText, { color: colors.primary }]}>
              CONNECTED
            </Text>
            <Pressable testID="disconnect-device" hitSlop={10} onPress={onDisconnect}>
              <Feather name="x-circle" size={20} color={colors.mutedForeground} />
            </Pressable>
          </View>
        ) : (
          <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
        )}
      </Pressable>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar style="light" />
      <Stack.Screen
        options={{
          title: "CONNECT DEVICE",
          headerStyle: { backgroundColor: colors.background },
          headerTintColor: colors.foreground,
          headerTitleStyle: { fontFamily: "Inter_700Bold", fontSize: 16 },
          headerShadowVisible: false,
          headerLeft: () => (
            <Pressable testID="pair-back" hitSlop={12} onPress={() => router.back()}>
              <Ionicons name="chevron-back" size={26} color={colors.foreground} />
            </Pressable>
          ),
        }}
      />

      <View style={styles.intro}>
        <Text style={[styles.introText, { color: colors.mutedForeground }]}>
          Power on your DMuffler dongle and join its WiFi hotspot, then scan to
          find it.
        </Text>
      </View>

      {(scanError || connectError) && (
        <View style={[styles.errorBox, { backgroundColor: colors.card }]}>
          <Feather name="alert-triangle" size={16} color={colors.primary} />
          <Text style={[styles.errorText, { color: colors.foreground }]}>
            {connectError ?? scanError}
          </Text>
        </View>
      )}

      <FlatList
        data={discoveredDevices}
        keyExtractor={(d) => d.id}
        renderItem={renderDevice}
        scrollEnabled={discoveredDevices.length > 0}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: bottomInset + 90 }}
        ListEmptyComponent={
          scanning ? (
            <View style={styles.emptyWrap}>
              <ActivityIndicator color={colors.primary} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Scanning for devices…
              </Text>
            </View>
          ) : (
            <View style={styles.emptyWrap}>
              <Ionicons name="bluetooth" size={28} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                No devices found yet
              </Text>
            </View>
          )
        }
        showsVerticalScrollIndicator={false}
      />

      <View
        style={[
          styles.scanWrap,
          { paddingBottom: bottomInset + 12, backgroundColor: colors.background },
        ]}
      >
        <Pressable
          testID="scan-devices"
          onPress={() => {
            if (Platform.OS !== "web") Haptics.selectionAsync();
            startScan();
          }}
          disabled={scanning}
          style={[
            styles.scanBtn,
            { backgroundColor: colors.primary, opacity: scanning ? 0.6 : 1 },
          ]}
        >
          {scanning ? (
            <ActivityIndicator size="small" color={colors.primaryForeground} />
          ) : (
            <Text style={[styles.scanText, { color: colors.primaryForeground }]}>
              SCAN AGAIN
            </Text>
          )}
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  intro: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 16 },
  introText: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 19 },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginHorizontal: 16,
    marginBottom: 12,
    padding: 12,
    borderRadius: 8,
  },
  errorText: { fontFamily: "Inter_400Regular", fontSize: 12, flex: 1 },
  deviceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 8,
    borderWidth: 2,
    marginBottom: 10,
  },
  deviceIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  deviceName: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  deviceMeta: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  connectedWrap: { flexDirection: "row", alignItems: "center", gap: 10 },
  connectedText: { fontFamily: "Inter_700Bold", fontSize: 11, letterSpacing: 1 },
  emptyWrap: { alignItems: "center", gap: 10, paddingTop: 48 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 13 },
  scanWrap: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  scanBtn: {
    borderRadius: 28,
    paddingVertical: 16,
    alignItems: "center",
    justifyContent: "center",
    minHeight: 52,
  },
  scanText: { fontFamily: "Inter_700Bold", fontSize: 15, letterSpacing: 1.5 },
});
