import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

export type SoundMode = "city" | "sport" | "own";
export type StartMode = "off" | "starter" | "dynamic";

export interface ModeSettings {
  volume: number;
  startMode: StartMode;
  idleSpeed: number;
  workingCycle: number;
  backfires: number;
}

export type CarSettings = Record<SoundMode, ModeSettings>;

const STORAGE_KEY = "dmuffler.soundSettings.v1";
const SELECTED_KEY = "dmuffler.selectedCar.v1";

const DEFAULT_MODE: ModeSettings = {
  volume: 0.7,
  startMode: "off",
  idleSpeed: 0.5,
  workingCycle: 0.5,
  backfires: 2,
};

function defaultCarSettings(): CarSettings {
  return {
    city: { ...DEFAULT_MODE },
    sport: { ...DEFAULT_MODE, volume: 0.85, workingCycle: 0.7, backfires: 3 },
    own: { ...DEFAULT_MODE },
  };
}

interface SoundSettingsContextValue {
  hydrated: boolean;
  selectedCarId: string | null;
  setSelectedCarId: (id: string) => void;
  getCarSettings: (carId: string) => CarSettings;
  getModeSettings: (carId: string, mode: SoundMode) => ModeSettings;
  updateModeSettings: (
    carId: string,
    mode: SoundMode,
    patch: Partial<ModeSettings>,
  ) => void;
}

const SoundSettingsContext = createContext<SoundSettingsContextValue | null>(
  null,
);

export function SoundSettingsProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [hydrated, setHydrated] = useState<boolean>(false);
  const [settings, setSettings] = useState<Record<string, CarSettings>>({});
  const [selectedCarId, setSelectedCarIdState] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [rawSettings, rawSelected] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEY),
          AsyncStorage.getItem(SELECTED_KEY),
        ]);
        if (rawSettings) setSettings(JSON.parse(rawSettings));
        if (rawSelected) setSelectedCarIdState(rawSelected);
      } catch {
        // ignore corrupt storage
      } finally {
        setHydrated(true);
      }
    })();
  }, []);

  const persist = useCallback((next: Record<string, CarSettings>) => {
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)).catch(() => {});
  }, []);

  const getCarSettings = useCallback(
    (carId: string): CarSettings => settings[carId] ?? defaultCarSettings(),
    [settings],
  );

  const getModeSettings = useCallback(
    (carId: string, mode: SoundMode): ModeSettings =>
      getCarSettings(carId)[mode],
    [getCarSettings],
  );

  const updateModeSettings = useCallback(
    (carId: string, mode: SoundMode, patch: Partial<ModeSettings>) => {
      setSettings((prev) => {
        const car = prev[carId] ?? defaultCarSettings();
        const next: Record<string, CarSettings> = {
          ...prev,
          [carId]: { ...car, [mode]: { ...car[mode], ...patch } },
        };
        persist(next);
        return next;
      });
    },
    [persist],
  );

  const setSelectedCarId = useCallback((id: string) => {
    setSelectedCarIdState(id);
    AsyncStorage.setItem(SELECTED_KEY, id).catch(() => {});
  }, []);

  const value = useMemo<SoundSettingsContextValue>(
    () => ({
      hydrated,
      selectedCarId,
      setSelectedCarId,
      getCarSettings,
      getModeSettings,
      updateModeSettings,
    }),
    [
      hydrated,
      selectedCarId,
      setSelectedCarId,
      getCarSettings,
      getModeSettings,
      updateModeSettings,
    ],
  );

  return (
    <SoundSettingsContext.Provider value={value}>
      {children}
    </SoundSettingsContext.Provider>
  );
}

export function useSoundSettings() {
  const ctx = useContext(SoundSettingsContext);
  if (!ctx) {
    throw new Error(
      "useSoundSettings must be used within a SoundSettingsProvider",
    );
  }
  return ctx;
}
