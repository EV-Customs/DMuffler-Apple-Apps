import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import type { CarSettings, ModeSettings, SoundMode } from "@/context/SoundSettingsContext";
import {
  createTransport,
  DeviceTransport,
  DiscoveredDevice,
  scanForDevices,
} from "@/lib/device/transport";

export type ConnectionStatus =
  | "disconnected"
  | "scanning"
  | "connecting"
  | "connected";

export type SyncStatus = "idle" | "syncing" | "synced" | "error";

const PAIRED_DEVICE_KEY = "dmuffler.pairedDevice.v1";

interface DeviceConnectionContextValue {
  status: ConnectionStatus;
  syncStatus: SyncStatus;
  connectedDevice: DiscoveredDevice | null;
  discoveredDevices: DiscoveredDevice[];
  scanError: string | null;
  connectError: string | null;
  startScan: () => Promise<void>;
  connectToDevice: (device: DiscoveredDevice) => Promise<void>;
  disconnect: () => Promise<void>;
  /** Push one mode's settings to the connected device (no-op when disconnected). */
  syncModeSettings: (
    carId: string,
    mode: SoundMode,
    settings: ModeSettings,
  ) => void;
  /** Push a full car profile to the connected device (no-op when disconnected). */
  syncProfile: (carId: string, settings: CarSettings) => void;
}

const DeviceConnectionContext =
  createContext<DeviceConnectionContextValue | null>(null);

export function DeviceConnectionProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [status, setStatus] = useState<ConnectionStatus>("disconnected");
  const [syncStatus, setSyncStatus] = useState<SyncStatus>("idle");
  const [connectedDevice, setConnectedDevice] =
    useState<DiscoveredDevice | null>(null);
  const [discoveredDevices, setDiscoveredDevices] = useState<
    DiscoveredDevice[]
  >([]);
  const [scanError, setScanError] = useState<string | null>(null);
  const [connectError, setConnectError] = useState<string | null>(null);

  const transportRef = useRef<DeviceTransport | null>(null);
  const syncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const syncResetRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingRef = useRef<{
    carId: string;
    mode: SoundMode;
    settings: ModeSettings;
  } | null>(null);

  // Auto-reconnect to the last paired device on launch.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(PAIRED_DEVICE_KEY);
        if (!raw || cancelled) return;
        const device = JSON.parse(raw) as DiscoveredDevice;
        setStatus("connecting");
        const transport = createTransport(device);
        await transport.connect();
        if (cancelled) {
          transport.disconnect().catch(() => {});
          return;
        }
        transportRef.current = transport;
        setConnectedDevice(device);
        setStatus("connected");
      } catch {
        if (!cancelled) setStatus("disconnected");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const startScan = useCallback(async () => {
    setScanError(null);
    setStatus((prev) => (prev === "connected" ? prev : "scanning"));
    setDiscoveredDevices([]);
    try {
      const devices = await scanForDevices();
      setDiscoveredDevices(devices);
    } catch (e) {
      setScanError(e instanceof Error ? e.message : "Scan failed");
    } finally {
      setStatus((prev) => (prev === "scanning" ? "disconnected" : prev));
    }
  }, []);

  const disconnect = useCallback(async () => {
    const transport = transportRef.current;
    transportRef.current = null;
    setConnectedDevice(null);
    setStatus("disconnected");
    setSyncStatus("idle");
    AsyncStorage.removeItem(PAIRED_DEVICE_KEY).catch(() => {});
    if (transport) await transport.disconnect().catch(() => {});
  }, []);

  const connectToDevice = useCallback(
    async (device: DiscoveredDevice) => {
      setConnectError(null);
      if (transportRef.current) {
        await disconnect();
      }
      setStatus("connecting");
      try {
        const transport = createTransport(device);
        await transport.connect();
        transportRef.current = transport;
        setConnectedDevice(device);
        setStatus("connected");
        AsyncStorage.setItem(PAIRED_DEVICE_KEY, JSON.stringify(device)).catch(
          () => {},
        );
      } catch (e) {
        setStatus("disconnected");
        setConnectError(
          e instanceof Error ? e.message : "Could not connect to device",
        );
        throw e;
      }
    },
    [disconnect],
  );

  const flushPending = useCallback(async () => {
    const transport = transportRef.current;
    const pending = pendingRef.current;
    pendingRef.current = null;
    if (!transport || !pending) return;
    setSyncStatus("syncing");
    try {
      await transport.sendSettings({
        carId: pending.carId,
        mode: pending.mode,
        settings: pending.settings,
      });
      setSyncStatus("synced");
      if (syncResetRef.current) clearTimeout(syncResetRef.current);
      syncResetRef.current = setTimeout(() => setSyncStatus("idle"), 2000);
    } catch {
      setSyncStatus("error");
      // If the device stopped responding, reflect that in the header.
      const alive = await transport.ping();
      if (!alive) {
        transportRef.current = null;
        setConnectedDevice(null);
        setStatus("disconnected");
      }
    }
  }, []);

  const syncModeSettings = useCallback(
    (carId: string, mode: SoundMode, settings: ModeSettings) => {
      if (!transportRef.current) return;
      pendingRef.current = { carId, mode, settings };
      if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
      // Debounce slider drags so we don't flood the device.
      syncTimerRef.current = setTimeout(() => {
        flushPending();
      }, 400);
    },
    [flushPending],
  );

  const syncProfile = useCallback((carId: string, settings: CarSettings) => {
    const transport = transportRef.current;
    if (!transport) return;
    setSyncStatus("syncing");
    transport
      .sendProfile(carId, settings)
      .then(() => {
        setSyncStatus("synced");
        if (syncResetRef.current) clearTimeout(syncResetRef.current);
        syncResetRef.current = setTimeout(() => setSyncStatus("idle"), 2000);
      })
      .catch(() => setSyncStatus("error"));
  }, []);

  useEffect(
    () => () => {
      if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
      if (syncResetRef.current) clearTimeout(syncResetRef.current);
    },
    [],
  );

  const value = useMemo<DeviceConnectionContextValue>(
    () => ({
      status,
      syncStatus,
      connectedDevice,
      discoveredDevices,
      scanError,
      connectError,
      startScan,
      connectToDevice,
      disconnect,
      syncModeSettings,
      syncProfile,
    }),
    [
      status,
      syncStatus,
      connectedDevice,
      discoveredDevices,
      scanError,
      connectError,
      startScan,
      connectToDevice,
      disconnect,
      syncModeSettings,
      syncProfile,
    ],
  );

  return (
    <DeviceConnectionContext.Provider value={value}>
      {children}
    </DeviceConnectionContext.Provider>
  );
}

export function useDeviceConnection() {
  const ctx = useContext(DeviceConnectionContext);
  if (!ctx) {
    throw new Error(
      "useDeviceConnection must be used within a DeviceConnectionProvider",
    );
  }
  return ctx;
}
