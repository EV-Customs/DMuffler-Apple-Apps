import { ImageSourcePropType } from "react-native";

export interface Car {
  id: string;
  name: string;
  image: ImageSourcePropType;
  subtitle?: string;
}

export const CARS: Car[] = [
  {
    id: "bmw-m4",
    name: "BMW M4",
    image: require("@/assets/images/cars/BMW_M4.png"),
  },
  {
    id: "ferrari-laferrari",
    name: "Ferrari LaFerrari",
    image: require("@/assets/images/cars/FERRARI_LAFERRARI.png"),
  },
  {
    id: "ford-model-t",
    name: "Ford Model T",
    image: require("@/assets/images/cars/FORD_MODEL_T.png"),
  },
  {
    id: "mustang-gt350",
    name: "Mustang GT350",
    image: require("@/assets/images/cars/FORD_MUSTANG_GT350.png"),
  },
  {
    id: "jaguar-e-type",
    name: "Jaguar E-Type",
    image: require("@/assets/images/cars/jaguar_e_type.png"),
  },
  {
    id: "mclaren-artura",
    name: "McLaren Artura",
    image: require("@/assets/images/cars/MCLAREN_ARTURA.png"),
  },
  {
    id: "porsche-911",
    name: "Porsche 911",
    image: require("@/assets/images/cars/PORSCHE_911.png"),
  },
  {
    id: "subaru-wrx-sti",
    name: "Subaru WRX STI",
    image: require("@/assets/images/cars/SUBARU_WRX_STI.png"),
  },
];

export const BOOMBOX_CARS: Car[] = [
  {
    id: "podracer",
    name: "Podracer",
    subtitle: "I will make it legal",
    image: require("@/assets/images/cars/STAR_WARS_PODRACER.png"),
  },
  {
    id: "tesla-roadster",
    name: "Tesla Roadster",
    subtitle: "Compressed air Space-X package",
    image: require("@/assets/images/cars/TESLA_ROADSTER.png"),
  },
];

export function getCar(id: string | undefined): Car | undefined {
  return [...CARS, ...BOOMBOX_CARS].find((c) => c.id === id);
}

export interface BoomboxProfile {
  id: string;
  name: string;
  desc: string;
  image: ImageSourcePropType;
}

export const BOOMBOX_PROFILES: BoomboxProfile[] = [
  {
    id: "lofi",
    name: "Lo-Fi Cruise",
    desc: "Chilled beats for city driving",
    image: require("@/assets/images/cars/LOFI_CRUISE.png"),
  },
  {
    id: "rain",
    name: "Rain & Thunder",
    desc: "Ambient storm soundscape",
    image: require("@/assets/images/cars/RAIN_THUNDER.png"),
  },
];
