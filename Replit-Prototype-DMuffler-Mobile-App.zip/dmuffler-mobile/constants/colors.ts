/**
 * Semantic design tokens for the DMuffler mobile app.
 *
 * Dark automotive theme. The palette is derived from the sibling web artifact
 * (artifacts/tesmuffler) — near-black surfaces with a bold red primary.
 * Dark is the default: the `light` key holds the dark theme values so the app
 * always renders dark regardless of the device appearance setting.
 */

const dark = {
  // Legacy aliases (kept for backward compatibility)
  text: "#ffffff",
  tint: "#B8191D",

  // Core surfaces
  background: "#0A0A0A",
  foreground: "#ffffff",

  // Cards / elevated surfaces
  card: "#141414",
  cardForeground: "#ffffff",

  // Primary action color (buttons, active states)
  primary: "#B8191D",
  primaryForeground: "#ffffff",

  // Secondary / less-emphasis interactive surfaces
  secondary: "#1c1c1c",
  secondaryForeground: "#ffffff",

  // Muted / subdued elements (dividers, timestamps, placeholders)
  muted: "#1c1c1c",
  mutedForeground: "#8a8a8a",

  // Accent highlights (badges, selected items, focus rings)
  accent: "#242424",
  accentForeground: "#ffffff",

  // Destructive actions
  destructive: "#B8191D",
  destructiveForeground: "#ffffff",

  // Borders and input outlines
  border: "#262626",
  input: "#262626",
};

const colors = {
  light: dark,
  dark,

  // Border radius (in px). Synced from the web artifact's --radius (0.5rem).
  radius: 8,
};

export default colors;
