import { Platform } from "react-native";

import type { CarSettings, ModeSettings, SoundMode } from "@/context/SoundSettingsContext";

/**
 * DMuffler device transport layer.
 *
 * The physical DMuffler OBD dongle exposes a WiFi hotspot (standard for OBD
 * dongles) with a small HTTP API. This file is the ONLY place that knows how
 * to talk to hardware — when the final firmware protocol (WiFi or BLE) is
 * confirmed, swap/extend the transport here and nothing else changes.
 */

export type TransportKind = "wifi" | "demo";

export interface DiscoveredDevice {
  id: string;
  name: string;
  kind: TransportKind;
  /** WiFi devices: the base URL of the dongle's HTTP API. */
  address?: string;
}

export interface DevicePayload {
  carId: string;
  mode: SoundMode;
  settings: ModeSettings;
}

export interface DeviceTransport {
  readonly device: DiscoveredDevice;
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  /** Push one mode's sound settings to the device. Throws on failure. */
  sendSettings(payload: DevicePayload): Promise<void>;
  /** Push the full profile for a car (all modes). Throws on failure. */
  sendProfile(carId: string, settings: CarSettings): Promise<void>;
  /** Lightweight liveness check. */
  ping(): Promise<boolean>;
}

const PROBE_TIMEOUT_MS = 2500;

/** Candidate hotspot addresses used by DMuffler / common OBD WiFi dongles. */
const WIFI_PROBE_ADDRESSES = [
  "http://192.168.4.1",
  "http://192.168.0.10:35000",
];

function fetchWithTimeout(url: string, init?: RequestInit, ms = PROBE_TIMEOUT_MS): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return fetch(url, { ...init, signal: controller.signal }).finally(() =>
    clearTimeout(timer),
  );
}

class WifiTransport implements DeviceTransport {
  constructor(readonly device: DiscoveredDevice) {}

  private url(path: string): string {
    return `${this.device.address}${path}`;
  }

  async connect(): Promise<void> {
    const res = await fetchWithTimeout(this.url("/status"));
    if (!res.ok) {
      throw new Error(`DMuffler device responded with ${res.status}`);
    }
  }

  async disconnect(): Promise<void> {
    // HTTP is connectionless; nothing to tear down.
  }

  async sendSettings(payload: DevicePayload): Promise<void> {
    const res = await fetchWithTimeout(this.url("/settings"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      throw new Error(`Settings sync failed (${res.status})`);
    }
  }

  async sendProfile(carId: string, settings: CarSettings): Promise<void> {
    const res = await fetchWithTimeout(this.url("/profile"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ carId, settings }),
    });
    if (!res.ok) {
      throw new Error(`Profile sync failed (${res.status})`);
    }
  }

  async ping(): Promise<boolean> {
    try {
      const res = await fetchWithTimeout(this.url("/status"), undefined, 1500);
      return res.ok;
    } catch {
      return false;
    }
  }
}

/**
 * In-app demo device so pairing and settings sync can be exercised without
 * hardware. Behaves like a real dongle with realistic latency.
 */
class DemoTransport implements DeviceTransport {
  constructor(readonly device: DiscoveredDevice) {}

  private delay(ms: number): Promise<void> {
    return new Promise((r) => setTimeout(r, ms));
  }

  async connect(): Promise<void> {
    await this.delay(900);
  }

  async disconnect(): Promise<void> {
    await this.delay(150);
  }

  async sendSettings(_payload: DevicePayload): Promise<void> {
    await this.delay(350);
  }

  async sendProfile(_carId: string, _settings: CarSettings): Promise<void> {
    await this.delay(500);
  }

  async ping(): Promise<boolean> {
    return true;
  }
}

export const DEMO_DEVICE: DiscoveredDevice = {
  id: "demo-dmuffler",
  name: "DMuffler Demo",
  kind: "demo",
};

export function createTransport(device: DiscoveredDevice): DeviceTransport {
  if (device.kind === "demo") return new DemoTransport(device);
  return new WifiTransport(device);
}

/**
 * Scan for DMuffler devices. Probes known WiFi hotspot addresses in parallel;
 * always appends the demo device so the flow works without hardware.
 */
export async function scanForDevices(): Promise<DiscoveredDevice[]> {
  const found: DiscoveredDevice[] = [];

  // Browsers block plain-HTTP requests from an HTTPS page (mixed content),
  // so hotspot probing only runs on native.
  const addresses = Platform.OS === "web" ? [] : WIFI_PROBE_ADDRESSES;
  const probes = addresses.map(async (address) => {
    try {
      const res = await fetchWithTimeout(`${address}/status`);
      if (res.ok) {
        let name = "DMuffler Device";
        try {
          const body = (await res.json()) as { name?: string };
          if (body?.name) name = body.name;
        } catch {
          // status endpoint may not return JSON; keep default name
        }
        found.push({ id: `wifi:${address}`, name, kind: "wifi", address });
      }
    } catch {
      // no device at this address
    }
  });

  await Promise.all(probes);
  found.push(DEMO_DEVICE);
  return found;
}
