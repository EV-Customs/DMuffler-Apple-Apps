import React, { useRef, useState } from "react";
import {
  GestureResponderEvent,
  LayoutChangeEvent,
  PanResponder,
  StyleSheet,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

import { useColors } from "@/hooks/useColors";

interface SliderProps {
  value: number;
  onChange: (value: number) => void;
  testID?: string;
}

const THUMB_SIZE = 24;
const TRACK_HEIGHT = 4;

export function Slider({ value, onChange, testID }: SliderProps) {
  const colors = useColors();
  const [width, setWidth] = useState<number>(0);
  const widthRef = useRef<number>(0);
  const lastHaptic = useRef<number>(value);

  const clamp = (v: number) => Math.min(1, Math.max(0, v));

  const handleMove = (evt: GestureResponderEvent) => {
    const w = widthRef.current;
    if (w <= 0) return;
    const x = evt.nativeEvent.locationX;
    const next = clamp(x / w);
    if (Platform.OS !== "web" && Math.abs(next - lastHaptic.current) > 0.05) {
      lastHaptic.current = next;
      Haptics.selectionAsync().catch(() => {});
    }
    onChange(next);
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: handleMove,
      onPanResponderMove: handleMove,
    }),
  ).current;

  const onLayout = (e: LayoutChangeEvent) => {
    const w = e.nativeEvent.layout.width;
    widthRef.current = w;
    setWidth(w);
  };

  const filled = clamp(value) * width;

  return (
    <View
      testID={testID}
      style={styles.container}
      onLayout={onLayout}
      {...panResponder.panHandlers}
    >
      <View
        style={[styles.track, { backgroundColor: colors.secondary }]}
      />
      <View
        style={[
          styles.track,
          styles.trackFill,
          { backgroundColor: colors.primary, width: filled },
        ]}
      />
      <View
        style={[
          styles.thumb,
          {
            backgroundColor: "#ffffff",
            left: Math.max(0, Math.min(width - THUMB_SIZE, filled - THUMB_SIZE / 2)),
          },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: THUMB_SIZE,
    justifyContent: "center",
    flex: 1,
  },
  track: {
    position: "absolute",
    left: 0,
    right: 0,
    height: TRACK_HEIGHT,
    borderRadius: TRACK_HEIGHT / 2,
  },
  trackFill: {
    right: undefined,
  },
  thumb: {
    position: "absolute",
    width: THUMB_SIZE,
    height: THUMB_SIZE,
    borderRadius: THUMB_SIZE / 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 2,
    elevation: 3,
  },
});
